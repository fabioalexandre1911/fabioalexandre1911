<?php

namespace App\Controllers;


use App\Libraries\Datatables; // Datatables
use App\Controllers\LoginController;
use App\Models\ProfessoresModel;
use \DateTime;


class ProfessoresController extends BaseController
{
    public $model;

    public function __construct()
    {
        $this->model = new ProfessoresModel();
    }

    # CARREGA TELA
    public function listar()
    {

    	# Verifica se existe alguem logado
        if(!LoginController::isLogged()){
            return redirect()->to("/logar");
        }

       	
        # Objetos criados para o controlador atual
        $datatable = new DataTables();

                
        # Rendereização dos escripts de JS E CSS
        $this->setJs($datatable->render()['js']);
        $this->setCss($datatable->render()['css']);
        $this->setJs(base_url() . "/public/services/professores/index.js");

        $data['title'] = "Listar";
        $data['result'] = $this->model->findAll();

        # Carregamento da view...
        echo $this->load("professores", "listar", $data);

    }

     public function form($id = null){
        //var_dump($livrosCadastrados);
        if($id != null){
            $data['result'] = $this->model->where('id_professor',$id)->first();
            $data['sub'] = "Editar Professor";
        }else{
           $data['result'] = array('id_professor'=>'', 'professor_nome'=>'', 'professor_curso'=>'','professor_contato'=>'','professor_criadoem'=>'');
            $data['sub'] = "Inserir Professor";
        }

        $data['title'] = "Formulario";

        echo $this->load("professores", "form", $data);

    }

    public function save(){

        $data = $this->request->getPost();
        $ret = $this->model->save($data);

        if($ret){
            $this->setMessage("success", "Dados salvos com sucesso!");
        }else{
            $this->setMessage("error", "Erro na operação!");            
        }
        return redirect()->to('/professores/listar');


    }

    public function delete($id){

        
        $ret = $this->model->delete($id);

        if($ret){
            $this->setMessage("success", "Dados excluídos com sucesso!");
        }else{
            $this->setMessage("error", "Erro na operação!");            
        }
        return redirect()->to('/professores/listar');

       


    }
    

}

