<?=$this->section('content');?>

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Listagem de Alunos</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"> Alunos </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Tabela de resultados -->
        <div class="card">
              <div class="card-header bg-gradient-secondary">
                <h3 class="card-title">
                    Listagem de Alunos <a href="<?=base_url();?>/alunos/inserir" class="btn btn-primary btn-sm"><i class="fa fa-plus-square"></i></a>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                

                <table id="example1" class="table table-bordered table-striped myTable table-sm" style="font-size: 12px !important">
					<thead class="bg-olive text-center">
					  <tr>
					    <th> ID </th>
					    <th> NOME </th>
					    <th> CPF </th>
					    <th> CONTATO </th>
					    <th> CRIADO EM </th>
					    <th> AÇÕES </th>					                        
					  </tr>
					</thead>
					<tbody class="text-center"> 
						
					  	<?php foreach ($result as $key => $value): ?>
					  		<tr>
					  			<td><?=$value['id_aluno'];?></td>
					  			<td><?=$value['aluno_nome'];?></td>
					  			<td><?=$value['aluno_cpf'];?></td>
					  			<td><?=$value['aluno_contato'];?></td>
					  			<td>
					  				<?=DateTime::createFromFormat('Y-m-d H:i:s', $value['aluno_criadoem'])->format("d/m/Y H:i:s");?></td>
					  			<td>
					  				<a href="<?=base_url();?>/alunos/editar/<?=$value['id_aluno'];?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a>	
                    <button class="btn btn-danger btn-xs" data-toggle=""><i class=" fa fa-trash"></i></button>
					  			</td>
					  		</tr>
					  	<?php endforeach; ?>
					</tbody>

					
                </table>
              </div>
              <!-- /.card-body -->
        </div>
      </div>
    
    </section>
    <!-- /.content -->
<?=$this->endSection(); ?>