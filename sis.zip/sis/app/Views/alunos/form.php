<?=$this->section('content');?>
	
	<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"> <?=$sub;?> </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"> Relatório </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Tabela de resultados -->
        <div class="card">
              <div class="card-header bg-gradient-secondary">
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                 <form action="<?=base_url();?>/alunos/salvar" method="POST">
					<div class="card-body row">
					<div class="form-group col-md-6">
					<label for="imputName">Nome</label>
					<input type="text" class="form-control" required name="aluno_nome" value="<?=$result['aluno_nome'];?>" placeholder="Nome Completo">
					</div>
					<div class="form-group col-md-6">
					<label for="imputName">Cpf</label>
					<input type="text" class="form-control" required name="aluno_cpf" value="<?=$result['aluno_cpf'];?>" placeholder="Insira seu Cpf">
					</div>
					<div class="form-group col-md-6">
					<label for="imputName">Contato</label>
					<input type="text" class="form-control" required name="aluno_contato" value="<?=$result['aluno_contato'];?>" placeholder="Insira seu Contato">
					</div>
					<div class="form-group col-md-6">
					<label for="imputName">Criado em</label>
					<input type="text" class="form-control" required name="aluno_criadoem" value="<?=$result['aluno_criadoem'];?>" placeholder="Data">
					</div>
					<input type="hidden" name="id_aluno" value="<?=$result['id_aluno'];?>">

					<div class="card-footer">
					<button type="submit" class="btn btn-success">Enviar</button>
					</div>
				</form>
              </div>
              <!-- /.card-body -->
        </div>
      </div>
    
    </section>

<?=$this->endSection(); ?>