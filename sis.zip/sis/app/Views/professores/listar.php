<?=$this->section('content');?>

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Listagem de Professores</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"> Professores </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Tabela de resultados -->
        <div class="card">
              <div class="card-header bg-gradient-secondary">
                <h3 class="card-title">
                    Listagem de Professores <a href="<?=base_url();?>/professores/inserir" class="btn btn-primary btn-sm"><i class="fa fa-plus-square"></i></a>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                

                <table id="example1" class="table table-bordered table-striped myTable table-sm" style="font-size: 12px !important">
					<thead class="bg-olive text-center">
					  <tr>
					    <th> ID </th>
					    <th> NOME </th>
					    <th> CURSO </th>
					    <th> CONTATO </th>
					    <th> CRIADO EM </th>
					    <th> AÇÕES </th>					                        
					  </tr>
					</thead>
					<tbody class="text-center"> 
						
					  	<?php foreach ($result as $key => $value): ?>
					  		<tr>
					  			<td><?=$value['id_professor'];?></td>
					  			<td><?=$value['professor_nome'];?></td>
					  			<td><?=$value['professor_curso'];?></td>
					  			<td><?=$value['professor_contato'];?></td>
					  			<td>
					  				<?=DateTime::createFromFormat('Y-m-d H:i:s', $value['professor_criadoem'])->format("d/m/Y H:i:s");?></td>
					  			<td>
					  				<a href="<?=base_url();?>/professores/editar/<?=$value['id_professor'];?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a> 

					  				<button class="btn btn-danger btn-xs" data-toggle="#excluir-<?=$value['id_professor'];?>" id="myModal"><i class=" fa fa-trash"></i></button>
					  				 
                     <!-- modal para excluir -->
                    <!-- Modal -->
                    <div class="modal fade" id="excluir-<?=$value['id_professor'];?>">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form action="<?-base_url();?>professores/excluir" method="POST">
                          <div class="modal-header">
                            <h4 class="modal-title">Excluir????</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            
                          </div>

                          <div class="modal-body">
                              <h5>Esta operação não pode ser desfeita. Tem Certeza?</h5>
                                <input type="hidden" name="id_professor" value="<?-$professor['id_professor'];?>">
                            </div>
                            <div class="modal-footer justifify-content-between">
                                <button type="" class="btn btn-danger">
                                  <span class="glyphicon glyphicon-ok-sign"></span>
                                  Sim, Excluir. 
                                </button>

                                <button type="button" class="btn btn-default" data-dismiss="modal" aria-lavel="Close">
                                  <span class="glyphicon glyphicon-remove-sign"></span>
                                  Não, Cancelar.
                                </button>
                              </div>

                              </form>
                          </div>

                        </div>
                      </div>
                    </div>
                    <!-- fim modal -->	

					  			</td>

					  		</tr>
					  	<?php endforeach; ?>
					</tbody>

					
                </table>
              </div>
              <!-- /.card-body -->
        </div>
      </div>
    
    </section>
    <!-- /.content -->
<?=$this->endSection(); ?>