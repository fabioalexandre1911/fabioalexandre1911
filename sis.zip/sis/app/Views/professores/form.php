<?=$this->section('content');?>
	
	<!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"> <?=$sub;?> </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"> Relatório </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Tabela de resultados -->
        <div class="card">
              <div class="card-header bg-gradient-secondary">
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                 <form action="<?=base_url();?>/professores/salvar" method="POST">
					<div class="card-body row">
					<div class="form-group col-md-6">
					<label for="imputName">Nome</label>
					<input type="text" class="form-control" required name="professor_nome" value="<?=$result['professor_nome'];?>" placeholder="Nome Completo">
					</div>
					<div class="form-group col-md-6">
					<label for="imputName">Curso</label>
					<input type="text" class="form-control" required name="professor_curso" value="<?=$result['professor_curso'];?>" placeholder="Insira seu Curso">
					</div>
					<div class="form-group col-md-6">
					<label for="imputName">Contato</label>
					<input type="text" class="form-control" required name="professor_contato" value="<?=$result['professor_contato'];?>" placeholder="Insira seu Contato">
					</div>
					<div class="form-group col-md-6">
					<label for="imputName">Criado em</label>
					<input type="text" class="form-control" required name="professor_criadoem" value="<?=$result['professor_criadoem'];?>" placeholder="Data">
					</div>
					<input type="hidden" name="id_professor" value="<?=$result['id_professor'];?>">

					<div class="card-footer">
					<button type="submit" class="btn btn-success">Enviar</button>
					</div>
				</form>
              </div>
              <!-- /.card-body -->
        </div>
      </div>
    
    </section>

<?=$this->endSection(); ?>