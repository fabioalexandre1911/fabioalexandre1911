<?php

namespace App\Models;

use CodeIgniter\Model;

#Conexão 

class ProfessoresModel extends Model
{    
    protected $DBGroup = "default";
    protected $table      = 'professores';
    protected $primaryKey = 'id_professor';
    protected $useAutoIncrement = true;
    protected $returnType     = 'array';
    protected $allowedFields = ['id_professor','professor_nome','professor_curso','professor_contato','professor_criadoem' ];


}

