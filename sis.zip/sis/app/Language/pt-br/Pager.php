<?php

return [
	'pageNavigation'         => 'Navegação de páginas',
	'first'                  => 'Primeira',
	'previous'               => 'Anterior',
	'next'                   => 'Próxima',
	'last'                   => 'Última',
	'older'                  => 'Mais antiga',
	'newer'                  => 'Mais recente',
	'invalidTemplate'        => '{0} não é um Pager template válido.',
	'invalidPaginationGroup' => '{0} não é um grupo de Paginação válido.',
];
