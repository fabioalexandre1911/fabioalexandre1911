<?php

return [
	'helpUsage'       => 'Uso:',
	'helpDescription' => 'Descrição:',
	'helpOptions'     => 'Opções:',
	'helpArguments'   => 'Argumentos:',
	'invalidColor'    => 'Cor de {0} inválida: {1}.',
];
